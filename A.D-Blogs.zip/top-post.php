<div class="top-posts">
    <img src="<?php echo $top_post_image ?>" alt="">
    <div class="post-info">
        <div class="tag-date">
            <p class="category"><i class="fa-duotone fa-tag"></i>&nbsp;<?php echo $top_post_category ?></p>|
            <p><i class="fa-solid fa-clock" style="color: #9e9e9e;"></i>&nbsp;<?php echo $top_post_date ?></p>
        </div>
        <a href="">
            <h1><?php echo $top_post_title ?></h1>
        </a>
        <div class="author-info">
            <i class="fa-duotone fa-user-pen"></i>
            <p><?php echo $top_post_author_firstname . "  " . $top_post_author_lastname ?></p>
            <p><i class="fa-solid fa-eye" style="color: #2270f7;"></i>&nbsp;<?php echo formatNumber($top_post_views) ?></p>
            <p><i class="fa-solid fa-heart" style="color: #ca3433;"></i>&nbsp;<?php echo formatNumber($top_post_likes) ?></p>
        </div>
    </div>
</div>
<hr>