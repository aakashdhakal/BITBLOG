
<?php

function get_author_info($username)
{
    $conn = new mysqli("localhost", "root", "", "blogs");
    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = mysqli_fetch_assoc($result);
    return $row;
}
